import pandas as pd
import numpy as np
from ctgan import CTGAN
import os
from sklearn.model_selection import train_test_split
from sklearn.mixture import GaussianMixture
from ctgan import CTGAN
from sklearn.naive_bayes import GaussianNB
import pickle
from sklearn.metrics import accuracy_score

# podaj nazwę pliku z rozszerzeniem .csv, albo jego dokładną lokalizacje
file_name = 'C:\\Users\\mwize\\Downloads\\syntheticDatactgan1000.csv'
# wskaż nazwy kolumn categorialne
categorical_features = ['SEX', 'Hypertension', 'Diabetes mellitus', 'Main ICD10']
# wybierz model jaki chcesz wygenerować:
# GMM / CTGAN
use_model = 'GMM'  # 'CTGAN'

if os.path.exists(file_name):

    df = pd.read_csv(f'{file_name}')
    train_df, test_df = train_test_split(df, test_size=0.3)
    test_size = test_df.shape[0]
    dfx, dfy = train_df.iloc[:, :-1], train_df.iloc[:, -1]


    def convert_to_df(ar, original_df=df):
        ndf = pd.DataFrame(ar)
        ndf.columns = original_df.columns.to_list()
        return ndf.astype(original_df.dtypes)


    def model_ctgan(data):
        ctg = CTGAN(embedding_dim=128,
                    generator_dim=(256, 256),
                    discriminator_dim=(256, 256),
                    generator_lr=8e-4,
                    generator_decay=1e-6,
                    discriminator_lr=8e-4,
                    discriminator_decay=1e-6,
                    verbose=True,
                    cuda=True,
                    epochs=1500)
        ctg.fit(data, categorical_features)
        # samples = ctg.sample(df.shape[0])
        return ctg, 'ctg'


    def model_gmm(data):
        data_arr = data.to_numpy()
        gm = GaussianMixture(n_components=data.shape[1]).fit(data_arr)
        # gmm_df_data = convert_to_df(gm.sample(n_samples=1000)[0])
        return gm, "gmm"


    def sample_model(model, model_type, samples):
        model_samples = model.sample(samples)
        if model_type == 'ctg':
            return model_samples
        elif model_type == 'gmm':
            return convert_to_df(model.sample(n_samples=samples)[0])


    def classificator(train_data, categorical_features):
        columns = [train_data.columns.get_loc(nazwa_kolumny) for nazwa_kolumny in categorical_features][-1]
        tr_data = train_data.copy()
        tr_data_x = tr_data.drop(df.columns[columns], axis=1)
        tr_data_y = tr_data.iloc[:, columns]

        gaussian_nb_classifier = GaussianNB()
        gaussian_nb_classifier.fit(tr_data_x, tr_data_y)

        return gaussian_nb_classifier


    if use_model.lower() == 'CTGAN'.lower():
        m, mtype = model_ctgan(train_df)
    elif use_model.lower() == 'GMM'.lower():
        m, mtype = model_gmm(train_df)

    print("Generator został utworzony\nObliczanie różnicy klasyfikatora")
    org_pred = []
    model_pred = []
    for i in range(100):
        org_nkb = classificator(train_df, categorical_features)

        if use_model.lower() == 'CTGAN'.lower():
            train_class = m.sample(train_df.shape[0])
        elif use_model.lower() == 'GMM'.lower():
            train_class = convert_to_df(m.sample(n_samples=train_df.shape[0])[0])

        model_nkb = classificator(train_class, categorical_features)

        org_pred.append(org_nkb.predict(test_df.iloc[:, :-1]))
        model_pred.append(model_nkb.predict(test_df.iloc[:, :-1]))

    acc = accuracy_score(np.concatenate(org_pred), np.tile(test_df.iloc[:, -1], 100)) - accuracy_score(np.concatenate(model_pred), np.tile(test_df.iloc[:, -1], 100))

    pickle.dump([m, acc], open("model.pickle", "wb"))
    print("Model został utworzony w miejscu lokalizacji skryptu")
else:
    print("Nie można odnaleźć pliku")
